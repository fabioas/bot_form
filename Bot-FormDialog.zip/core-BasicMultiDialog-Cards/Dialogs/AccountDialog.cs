﻿namespace BasicMultiDialogBot.Dialogs
{
    using Microsoft.Bot.Builder.Dialogs;
    using System;
    using System.Threading.Tasks;
    using Microsoft.Bot.Connector;

    [Serializable]
    public class AccountDialog : IDialog<int>
    {
        private string name;
        private int attempts = 3;

        public AccountDialog(string name)
        {
            this.name = name;
        }

        public async Task StartAsync(IDialogContext context)
        {
            await context.PostAsync($"{ this.name }, Qual é o número da sua conta?");

            context.Wait(this.MessageReceivedAsync);
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;

            int account;

            if (Int32.TryParse(message.Text, out account) && (account > 0))
            {
                context.Done(account);
            }
            else
            {
                --attempts;
                if (attempts > 0)
                {
                    await context.PostAsync("Desculpe, Eu não antendi. Qual é o número da sua conta (ex. '0000')?");

                    context.Wait(this.MessageReceivedAsync);
                }
                else
                {
                    context.Fail(new TooManyAttemptsException("Esta não é uma conta válida."));
                }
            }
        }
    }
}