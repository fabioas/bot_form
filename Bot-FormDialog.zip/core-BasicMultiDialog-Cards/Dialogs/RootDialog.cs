﻿namespace BasicMultiDialogBot.Dialogs
{
    using System;
    using System.Threading.Tasks;
    using Microsoft.Bot.Builder.Dialogs;
    using Microsoft.Bot.Connector;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using AdaptiveCards;
    using System.Threading;
    using System.Linq;

#pragma warning disable 1998

    [Serializable]
    public class RootDialog : IDialog<object>
    {

        private string name;
        private int age;
        private int account;
      

        public async Task StartAsync(IDialogContext context)
        {
            /* Wait until the first message is received from the conversation and call MessageReceviedAsync 
             *  to process that message. */
            context.Wait(this.MessageReceivedAsync);
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            /* When MessageReceivedAsync is called, it's passed an IAwaitable<IMessageActivity>. To get the message,
             *  await the result. */
            var message = await result;

            await this.SendWelcomeMessageAsync(context);
        }

        private async Task SendWelcomeMessageAsync(IDialogContext context)
        {
            await context.PostAsync("Olá, Eu sou um robô. Irei auxilia-lo em seu acesso a sua conta, vamos lá!.");
          
            context.Call(new NameDialog(), this.NameDialogResumeAfter);
        }

        private async Task SendTransfDoneMessageAsync(IDialogContext context)
        {
            await context.PostAsync("Transferência realizada com sucesso!");
            await context.PostAsync("Até logo!.");
           

            // context.Call(new NameDialog(), this.AccountDialogResumeAfter);
        }

        // transferência
        //public virtual async Task SendConfirmMessageAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        //{
        //    var message = await result;
          

        //    if (message.Value != null)
        //    {
        //        // Got an Action Submit
        //        dynamic value = message.Value;
        //        string submitType = value.Type.ToString();
        //        if (submitType=="transf")
        //        {
                    
        //               // TransfQuery query;
        //                try
        //                {
        //                //query = TransfQuery.Parse(value);

        //                //// Trigger validation using Data Annotations attributes from the HotelsQuery model
        //                //List<ValidationResult> results = new List<ValidationResult>();
        //                //bool valid = Validator.TryValidateObject(query, new ValidationContext(query, null, null), results, true);
        //                //if (!valid)
        //                //{
        //                //    // Some field in the Hotel Query are not valid
        //                //    var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
        //                //    await context.PostAsync("Please complete all the search parameters:\n" + errors);
        //                    await context.PostAsync("Transferência realizada com sucesso!");
        //                    return;
        //                        }
                     
        //                catch (InvalidCastException)
        //                {
        //                    // Hotel Query could not be parsed
        //                    await context.PostAsync("Transferência realizada com sucesso!");
        //                    return;
        //                }

        //            }
        //    }
            
        //    if (message.Text != null && (message.Text.ToLower().Contains("Não") || message.Text.ToLower().Contains("Obrigado") || message.Text.ToLower().Contains("tchau")))
        //    {
        //        //await this.SendFinishMessageAsync(context);
        //    }
        //    else
        //    {
        //        await ShowOptionsAsync(context);
        //    }
        //}

        private async Task NameDialogResumeAfter(IDialogContext context, IAwaitable<string> result)
        {
            try
            {
                this.name = await result;

                context.Call(new AgeDialog(this.name), this.AgeDialogResumeAfter);
            }
            catch (TooManyAttemptsException)
            {
                await context.PostAsync("Desculpe, Eu não entendi!. Vamos tentar novamente.");

                await this.SendWelcomeMessageAsync(context);
            }
        }
        private async Task AgeDialogResumeAfter(IDialogContext context, IAwaitable<int> result)
        {
            try
            {
                this.age = await result;

                //await context.PostAsync($"Sua agência é { age }.");
                context.Call(new AccountDialog(this.name), this.AccountDialogResumeAfter);
            }
            catch (TooManyAttemptsException)
            {
                await context.PostAsync("Desculpe, Eu não entendi!. Vamos tentar novamente.");
            }
         
        }
        private async Task AccountDialogResumeAfter(IDialogContext context, IAwaitable<int> result)
        {
            try
            {
                this.account = await result;

                //await context.PostAsync($"Seu nome é { name } , sua agência é { age } e sua conta é {account}.");
               await DisplaySelectedCard(context);

               await ShowOptionsAsync(context);

              // await context.PostAsync("");

            }
            catch (TooManyAttemptsException)
            {
                await context.PostAsync("Desculpe, Eu não entendi!. Vamos tentar novamente.");
            }

            //finally
            //{
            //    await this.SendFinishMessageAsync(context);
            //}
        }

        // Cards
        private async Task ShowOptionsAsync(IDialogContext context)
        {
            AdaptiveCard card = new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                    new Container()
                    {
                        Speak = "<s>Olá, o que gostaria de realizar?</s>",
                        Items = new List<CardElement>()
                        {
                            new ColumnSet()
                            {
                                Columns = new List<Column>()
                                {
                                    new Column()
                                    {
                                        Size = ColumnSize.Auto,
                                        Items = new List<CardElement>()
                                        {
                                            new Image()
                                            {
                                                Url = "https://4.bp.blogspot.com/-jTe_cIzsUck/WExkHNdRo9I/AAAAAAABkDE/lAvJLCY0-8EBPqivnUCw-d9dQS7cvL0OACLcB/s1600/BB%2Blogo.jpg",
                                                //Url = "https://placeholdit.imgix.net/~text?txtsize=65&txt=Adaptive+Cards&w=300&h=300",
                                                Size = ImageSize.Medium,
                                                Style = ImageStyle.Person
                                            }
                                        }
                                    },
                                    new Column()
                                    {
                                        Size = ColumnSize.Stretch,
                                        Items = new List<CardElement>()
                                        {
                                            new TextBlock()
                                            {
                                                Text =  "Olá!",
                                                Weight = TextWeight.Bolder,
                                                IsSubtle = true
                                            },
                                            new TextBlock()
                                            {
                                                Text = "Olá, o que gostaria de realizar?",
                                                Wrap = true
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                // Buttons
                Actions = new List<ActionBase>() {
                    new ShowCardAction()
                    {
                        Title = "Agendar Transferência",
                        Speak = "<s>Agendar Transferência</s>",
                        Card = GetHotelSearchCard()
                    },
                    new ShowCardAction()
                    {
                        Title = "Consultar Saldo",
                        Speak = "<s>Saldo</s>",
                        Card = new AdaptiveCard()
                        {
                            Body = new List<CardElement>()
                            {
                                new TextBlock()
                                {
                                    Text = "Seu Saldo é: R$ 50.000,00",
                                    Speak = "<s>Seu Saldo é",
                                    Weight = TextWeight.Bolder
                                }
                            }
                        }
                    }
                }
            };

            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            var reply = context.MakeMessage();
            reply.Attachments.Add(attachment);

            await context.PostAsync(reply, CancellationToken.None);

            //context.Wait(this.MessageReceivedAsync);

        }
        private async Task ResumeAfterOptionDialog(IDialogContext context, IAwaitable<object> result)
        {
            //context.Wait(this.SendConfirmMessageAsync);
            //context.Wait(this.MessageReceivedAsync);
            await this.SendTransfDoneMessageAsync(context);
        }
        public async Task DisplaySelectedCard(IDialogContext context)
        {
            var message = context.MakeMessage();

            var attachment = GetHeroCard();
            message.Attachments.Add(attachment);

            await context.PostAsync(message);
         
        }



        private Attachment GetHeroCard()
        {
            var heroCard = new HeroCard
            {
                Title = name,
                Subtitle = "Agência: " + Convert.ToString(age),
                Text = "Conta: " + Convert.ToString(account),
                Images = new List<CardImage> { new CardImage("http://2qwja22n0sx13mtdob3r3y5w1b38.wpengine.netdna-cdn.com/wp-content/uploads/2013/12/banco-do-brasil-2.png") },
                Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Acesse sua conta", value: "http://www.bb.com.br") }

            };

            return heroCard.ToAttachment();
        }
        private static AdaptiveCard GetHotelSearchCard()
        {
            return new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                        // Hotels Search form
                        new TextBlock()
                        {
                            Text = "Assistente para transferência!",
                            Speak = "<s>Olá, bem vindo ao assistente para transferência!</s>",
                            Weight = TextWeight.Bolder,
                            Size = TextSize.Large
                        },
                        new TextBlock() { Text = "Por favor insira a Agência/Conta de destino" },
                        new TextInput()
                        {
                            Id = "Insira a conta de destino",
                            Speak = "<s>Insira a conta de destino</s>",
                            Placeholder = "1234/7654321",
                            Style = TextInputStyle.Text
                        },
                        new TextBlock() { Text = "Quando você deseja realizar essa transferência?" },
                        new DateInput()
                        {
                            Id = "Checkin",
                            Speak = "<s>When do you want to check in?</s>"
                        },
                        new TextBlock() { Text = "Quanto você deseja transferir" },
                        new NumberInput()
                        {
                            Id = "Reais(R$)",
                            Min = 1,
                            Max = 60,
                            Speak = "<s>Quanto você deseja transferir</s>"
                        }
                },
                Actions = new List<ActionBase>()
                {
                    new SubmitAction()
                    {
                        Title = "Transferir",
                        Speak = "<s>Transferir</s>",
                        DataJson = "{ \"Type\": \"Transf\" }"
                    }
                }
            };
        }

 
    }
}

    
